package com.dbs.quoteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
